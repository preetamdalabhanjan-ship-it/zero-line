module.exports = {
  content: ['./src/index.src.html'],
  darkMode: 'class',
  theme: {
    fontFamily: {
      sans: ['ui-sans-serif', 'system-ui', '-apple-system', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'sans-serif'],
      mono: ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Consolas', 'monospace'],
    },
    fontSize: {
      '2xs': ['0.75rem', '1.1rem'],
      xs: ['0.8125rem', '1.25rem'],
      sm: ['0.9rem', '1.4rem'],
      base: ['1rem', '1.5rem'],
      lg: ['1.125rem', '1.6rem'],
      xl: ['1.3rem', '1.75rem'],
      '2xl': ['1.5rem', '2rem'],
      '3xl': ['1.85rem', '2.3rem'],
    },
    borderRadius: { none: '0', sm: '4px', DEFAULT: '6px', md: '6px', lg: '8px', xl: '10px', '2xl': '12px', '3xl': '14px', full: '9999px' },
    boxShadow: { none: 'none', sm: 'none', DEFAULT: 'none', md: 'none', lg: 'none', xl: 'none', inner: 'none', '2xl': '0 24px 48px rgba(0,0,0,.35)' },
    extend: {
      colors: {
      slate: { '50': 'rgb(var(--slate-50) / <alpha-value>)', '100': 'rgb(var(--slate-100) / <alpha-value>)', '200': 'rgb(var(--slate-200) / <alpha-value>)', '300': 'rgb(var(--slate-300) / <alpha-value>)', '400': 'rgb(var(--slate-400) / <alpha-value>)', '500': 'rgb(var(--slate-500) / <alpha-value>)', '600': 'rgb(var(--slate-600) / <alpha-value>)', '700': 'rgb(var(--slate-700) / <alpha-value>)', '800': 'rgb(var(--slate-800) / <alpha-value>)', '900': 'rgb(var(--slate-900) / <alpha-value>)', '950': 'rgb(var(--slate-950) / <alpha-value>)' },
      teal: { '50': 'rgb(var(--teal-50) / <alpha-value>)', '100': 'rgb(var(--teal-100) / <alpha-value>)', '200': 'rgb(var(--teal-200) / <alpha-value>)', '300': 'rgb(var(--teal-300) / <alpha-value>)', '400': 'rgb(var(--teal-400) / <alpha-value>)', '500': 'rgb(var(--teal-500) / <alpha-value>)', '600': 'rgb(var(--teal-600) / <alpha-value>)', '700': 'rgb(var(--teal-700) / <alpha-value>)', '800': 'rgb(var(--teal-800) / <alpha-value>)', '900': 'rgb(var(--teal-900) / <alpha-value>)', '950': 'rgb(var(--teal-950) / <alpha-value>)' },
      emerald: { '50': 'rgb(var(--emerald-50) / <alpha-value>)', '100': 'rgb(var(--emerald-100) / <alpha-value>)', '200': 'rgb(var(--emerald-200) / <alpha-value>)', '300': 'rgb(var(--emerald-300) / <alpha-value>)', '400': 'rgb(var(--emerald-400) / <alpha-value>)', '500': 'rgb(var(--emerald-500) / <alpha-value>)', '600': 'rgb(var(--emerald-600) / <alpha-value>)', '700': 'rgb(var(--emerald-700) / <alpha-value>)', '800': 'rgb(var(--emerald-800) / <alpha-value>)', '900': 'rgb(var(--emerald-900) / <alpha-value>)', '950': 'rgb(var(--emerald-950) / <alpha-value>)' },
      rose: { '50': 'rgb(var(--rose-50) / <alpha-value>)', '100': 'rgb(var(--rose-100) / <alpha-value>)', '200': 'rgb(var(--rose-200) / <alpha-value>)', '300': 'rgb(var(--rose-300) / <alpha-value>)', '400': 'rgb(var(--rose-400) / <alpha-value>)', '500': 'rgb(var(--rose-500) / <alpha-value>)', '600': 'rgb(var(--rose-600) / <alpha-value>)', '700': 'rgb(var(--rose-700) / <alpha-value>)', '800': 'rgb(var(--rose-800) / <alpha-value>)', '900': 'rgb(var(--rose-900) / <alpha-value>)', '950': 'rgb(var(--rose-950) / <alpha-value>)' },
      amber: { '50': 'rgb(var(--amber-50) / <alpha-value>)', '100': 'rgb(var(--amber-100) / <alpha-value>)', '200': 'rgb(var(--amber-200) / <alpha-value>)', '300': 'rgb(var(--amber-300) / <alpha-value>)', '400': 'rgb(var(--amber-400) / <alpha-value>)', '500': 'rgb(var(--amber-500) / <alpha-value>)', '600': 'rgb(var(--amber-600) / <alpha-value>)', '700': 'rgb(var(--amber-700) / <alpha-value>)', '800': 'rgb(var(--amber-800) / <alpha-value>)', '900': 'rgb(var(--amber-900) / <alpha-value>)', '950': 'rgb(var(--amber-950) / <alpha-value>)' },
      blue: { '50': 'rgb(var(--blue-50) / <alpha-value>)', '100': 'rgb(var(--blue-100) / <alpha-value>)', '200': 'rgb(var(--blue-200) / <alpha-value>)', '300': 'rgb(var(--blue-300) / <alpha-value>)', '400': 'rgb(var(--blue-400) / <alpha-value>)', '500': 'rgb(var(--blue-500) / <alpha-value>)', '600': 'rgb(var(--blue-600) / <alpha-value>)', '700': 'rgb(var(--blue-700) / <alpha-value>)', '800': 'rgb(var(--blue-800) / <alpha-value>)', '900': 'rgb(var(--blue-900) / <alpha-value>)', '950': 'rgb(var(--blue-950) / <alpha-value>)' },
      page: 'rgb(var(--page) / <alpha-value>)',
      zinc: { '800': 'rgb(var(--slate-800) / <alpha-value>)', '700': 'rgb(var(--slate-700) / <alpha-value>)' },
      },
    },
  },
  corePlugins: { preflight: true },
};
